interface Wialon {

}
declare var wialon: any;