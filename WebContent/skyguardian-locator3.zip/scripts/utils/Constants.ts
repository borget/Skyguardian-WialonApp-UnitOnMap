module Utils {
	export class Constants {
		public static WIALON_APP = "http://localhost:8080/Skyguardian-UnitMapTrackerWialonApp/?baseUrl=https://hst-api.wialon.com&hostUrl=http://by.hosting.wialon.com&lang=en&user=";
		public static GURTAM_BASE_URL = "https://hst-api.wialon.com";
		public static WSDK_URL = "https://hst-api.wialon.com/wsdk/script/wialon.js"
	}
}