var Utils;
(function (Utils) {
    var Constants = (function () {
        function Constants() {
        }
        Constants.WIALON_APP = "http://localhost:8080/Skyguardian-UnitMapTrackerWialonApp/?user=";
        Constants.GURTAM_BASE_URL = "https://hst-api.wialon.com";
        Constants.WSDK_URL = "https://hst-api.wialon.com/wsdk/script/wialon.js";
        return Constants;
    })();
    Utils.Constants = Constants;
})(Utils || (Utils = {}));
//# sourceMappingURL=Constants.js.map
