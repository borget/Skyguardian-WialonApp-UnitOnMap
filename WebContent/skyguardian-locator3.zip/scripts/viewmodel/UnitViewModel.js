/// <reference path="../typings/knockout.d.ts" />
var Skyguardian;
(function (Skyguardian) {
    var UnitViewModel = (function () {
        function UnitViewModel(unitId, unitName) {
            this.unitId = unitId;
            this.unitName = unitName;
        }
        return UnitViewModel;
    })();
    Skyguardian.UnitViewModel = UnitViewModel;
})(Skyguardian || (Skyguardian = {}));
//# sourceMappingURL=UnitViewModel.js.map
