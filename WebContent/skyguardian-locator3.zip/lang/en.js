TRANSLATIONS = {
	"Icon": "",

	"Name": "",

	"Last message": "",

	"Speed": "",
	
	"km/h": "",
	
	"mph": "",
	
	"Location": "",

    "Sunday": "",
    "Monday": "",
    "Tuesday": "",
    "Wednesday": "",
    "Thursday": "",
    "Friday": "",
    "Saturday": "",

    "January": "",
    "February": "",
    "March": "",
    "April": "",
    "May": "",
    "June": "",
    "July": "",
    "August": "",
    "September": "",
    "October": "",
    "November": "",
    "December": "",

    "Sun": "",
    "Mon": "",
    "Tue": "",
    "Wed": "",
    "Thu": "",
    "Fri": "",
    "Sat": "",

    "Jan": "",
    "Feb": "",
    "Mar": "",
    "Apr": "",
    "Jun": "",
    "Jul": "",
    "Aug": "",
    "Sep": "",
    "Oct": "",
    "Nov": "",
    "Dec": ""
};
